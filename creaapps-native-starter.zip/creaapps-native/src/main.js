import { Capacitor } from '@capacitor/core';
import { Geolocation } from '@capacitor/geolocation';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { LocalNotifications } from '@capacitor/local-notifications';
import './style.css';

const $ = (q) => document.querySelector(q);
const state = {
  file: 'html',
  files: {
    html: '<!doctype html>\n<html lang="es">\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mi app</title></head>\n<body><h1>¡Mi primera aplicación!</h1><p>Modifica este código y pulsa Ejecutar.</p></body>\n</html>',
    css: 'body { font-family: system-ui, sans-serif; padding: 24px; color: #172033; }\nh1 { color: #6d28d9; }',
    js: 'console.log("Aplicación iniciada");'
  },
  currentId: null
};
const isNative = Capacitor.isNativePlatform();

$('#app').innerHTML = `
<header class="top"><div class="brand"><div class="logo">C</div><div><h1>CreaApps Studio</h1><p>Editor multiplataforma con funciones nativas</p></div></div><span class="tag" id="platformTag"></span></header>
<section class="hero"><h2>Tu idea se convierte en una app.</h2><p>Pega código, pruébalo y utiliza capacidades del dispositivo. Las funciones nativas estarán disponibles en Android/iOS; la web usa alternativas compatibles.</p></section>
<div class="layout">
<section class="panel"><div class="panelhead"><h3>Editor de proyecto</h3><button id="saveBtn">Guardar</button></div><div class="content">
<label>Nombre del proyecto<input id="projectName" value="Mi aplicación" maxlength="80"></label>
<div class="tabs"><button data-file="html" class="active">index.html</button><button data-file="css">style.css</button><button data-file="js">script.js</button></div>
<textarea id="editor" spellcheck="false" autocapitalize="off"></textarea>
<div class="actions"><button class="primary" id="runBtn">▶ Ejecutar vista previa</button><button id="exportBtn">Exportar HTML</button><button id="importBtn">Importar archivo</button><input type="file" id="fileInput" accept=".html,.htm,.css,.js,.txt" hidden></div>
<p class="hint">Los proyectos grandes dependen del espacio disponible en el dispositivo. No se impone un límite de líneas, pero la memoria y el navegador sí tienen límites técnicos.</p>
</div></section>
<section class="panel"><div class="panelhead"><h3>Vista previa</h3><span class="tag">Sandbox</span></div><div class="content"><iframe id="preview" sandbox="allow-scripts allow-forms allow-modals" title="Vista previa"></iframe>
<h3 class="subhead">Funciones del dispositivo</h3><div class="nativegrid">
<button id="gpsBtn">📍 Obtener GPS</button><button id="cameraBtn">📷 Abrir cámara</button><button id="notifyBtn">🔔 Notificación</button><button id="fileBtn">💾 Guardar archivo</button>
</div><pre id="nativeOutput" aria-live="polite">Estado: listo. Elige una función.</pre><img id="cameraImage" alt="Foto capturada" hidden></div></section>
</div>
<section class="panel projects"><div class="panelhead"><h3>Mis proyectos guardados</h3><button id="refreshBtn">Actualizar</button></div><div class="content"><div id="projectList" class="projectList"></div><p class="hint">Los proyectos se guardan localmente. Exporta una copia de seguridad si quieres conservarlos fuera de este navegador.</p></div></section>
<footer>Prototipo de CreaApps Studio · Las funciones nativas solicitan permisos y dependen del sistema operativo.</footer>
`;

$('#platformTag').textContent = isNative ? `App nativa · ${Capacitor.getPlatform()}` : 'Modo navegador';
const output = (message) => { $('#nativeOutput').textContent = message; };
function syncEditor() {
  state.files[state.file] = $('#editor').value;
  const count = Object.values(state.files).reduce((n, s) => n + s.length, 0);
  $('.hint').dataset.chars = `${count.toLocaleString('es')} caracteres en el proyecto`;
}
function setFile(name) {
  state.files[state.file] = $('#editor').value;
  state.file = name;
  $('#editor').value = state.files[name] || '';
  document.querySelectorAll('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.file === name));
}
document.querySelectorAll('.tabs button').forEach(b => b.addEventListener('click', () => setFile(b.dataset.file)));
$('#editor').value = state.files.html;
$('#editor').addEventListener('input', syncEditor);

function buildHtml() {
  state.files[state.file] = $('#editor').value;
  let html = state.files.html || '<!doctype html><html><head><meta charset="utf-8"></head><body></body></html>';
  const css = `<style>\n${state.files.css || ''}\n</style>`;
  const js = `<script>\n${state.files.js || ''}\n<\/script>`;
  html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, `${css}\n</head>`) : `${css}${html}`;
  html = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${js}\n</body>`) : `${html}${js}`;
  return html;
}
$('#runBtn').addEventListener('click', () => {
  try { $('#preview').srcdoc = buildHtml(); output('Vista previa actualizada.'); }
  catch (e) { output(`Error de vista previa: ${e.message}`); }
});
function download(name, text, mime) {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
$('#exportBtn').addEventListener('click', () => download('mi-aplicacion.html', buildHtml(), 'text/html'));
$('#importBtn').addEventListener('click', () => $('#fileInput').click());
$('#fileInput').addEventListener('change', async e => {
  const f = e.target.files?.[0]; if (!f) return;
  const ext = f.name.split('.').pop().toLowerCase();
  const target = ext === 'css' ? 'css' : ext === 'js' ? 'js' : 'html';
  setFile(target); $('#editor').value = await f.text(); state.files[target] = $('#editor').value;
  output(`Importado: ${f.name}`); e.target.value = '';
});

function getProjects() {
  try { return JSON.parse(localStorage.getItem('creaapps-projects') || '[]'); }
  catch { return []; }
}
function renderProjects() {
  const el = $('#projectList'); el.replaceChildren();
  for (const project of getProjects()) {
    const card = document.createElement('div'); card.className = 'projectCard';
    const title = document.createElement('strong'); title.textContent = project.name;
    const date = document.createElement('small'); date.textContent = project.updated;
    const open = document.createElement('button'); open.textContent = 'Abrir';
    open.addEventListener('click', () => {
      state.currentId = project.id; state.files = { ...project.files }; $('#projectName').value = project.name;
      setFile('html'); $('#editor').value = state.files.html || ''; output(`Proyecto abierto: ${project.name}`);
    });
    const remove = document.createElement('button'); remove.textContent = 'Borrar';
    remove.addEventListener('click', () => {
      localStorage.setItem('creaapps-projects', JSON.stringify(getProjects().filter(p => p.id !== project.id)));
      renderProjects();
    });
    card.append(title, date, open, remove); el.append(card);
  }
  if (!el.children.length) el.textContent = 'Todavía no hay proyectos guardados.';
}
$('#saveBtn').addEventListener('click', () => {
  syncEditor();
  const all = getProjects(), id = state.currentId || `p-${Date.now()}`;
  const item = { id, name: $('#projectName').value.trim() || 'Mi aplicación', files: state.files, updated: new Date().toLocaleString('es') };
  const index = all.findIndex(p => p.id === id);
  if (index >= 0) all[index] = item; else all.unshift(item);
  try {
    localStorage.setItem('creaapps-projects', JSON.stringify(all)); state.currentId = id;
    renderProjects(); output('Proyecto guardado en este dispositivo.');
  } catch { output('No hay espacio suficiente. Exporta el proyecto y libera espacio.'); }
});
$('#refreshBtn').addEventListener('click', renderProjects);
renderProjects();
$('#preview').srcdoc = '<body style="font-family:system-ui;padding:24px"><h2>Tu vista previa aparecerá aquí</h2><p>Modifica el código y pulsa Ejecutar.</p></body>';

$('#gpsBtn').addEventListener('click', async () => {
  try {
    if (!isNative && !navigator.geolocation) throw new Error('GPS no disponible en este navegador.');
    const pos = isNative
      ? await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 15000 })
      : await new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true, timeout: 15000 }));
    const c = pos.coords;
    output(`Ubicación obtenida:\nLatitud: ${c.latitude}\nLongitud: ${c.longitude}\nPrecisión: ${Math.round(c.accuracy)} m\nNota: esta acción obtiene una ubicación puntual, no seguimiento continuo en segundo plano.`);
  } catch (e) { output(`No se pudo obtener GPS. Comprueba permisos y ubicación del dispositivo.\nDetalle: ${e.message}`); }
});
$('#cameraBtn').addEventListener('click', async () => {
  try {
    if (isNative) {
      const photo = await Camera.getPhoto({ quality: 80, allowEditing: false, resultType: CameraResultType.DataUrl, source: CameraSource.Prompt });
      $('#cameraImage').src = photo.dataUrl; $('#cameraImage').hidden = false;
      output('Foto capturada.'); 
    } else {
      const input = document.createElement('input'); input.type = 'file'; input.accept = 'image/*'; input.capture = 'environment';
      input.onchange = () => { const f = input.files?.[0]; if (!f) return; $('#cameraImage').src = URL.createObjectURL(f); $('#cameraImage').hidden = false; output('Imagen seleccionada desde el navegador.'); };
      input.click();
    }
  } catch (e) { output(`Cámara cancelada o no disponible: ${e.message}`); }
});
$('#notifyBtn').addEventListener('click', async () => {
  try {
    if (isNative) {
      let perm = await LocalNotifications.checkPermissions();
      if (perm.display !== 'granted') perm = await LocalNotifications.requestPermissions();
      if (perm.display !== 'granted') throw new Error('Permiso de notificaciones denegado.');
      await LocalNotifications.schedule({ notifications: [{ id: Math.floor(Date.now() % 2147483647), title: 'CreaApps', body: '¡Tu notificación de prueba funciona!', schedule: { at: new Date(Date.now() + 1500) } }] });
      output('Notificación programada para dentro de unos segundos.');
    } else if ('Notification' in window) {
      let perm = Notification.permission;
      if (perm === 'default') perm = await Notification.requestPermission();
      if (perm === 'granted') { new Notification('CreaApps', { body: 'Notificación de prueba.' }); output('Notificación enviada por el navegador.'); }
      else throw new Error('Permiso de notificaciones denegado o no compatible.');
    } else throw new Error('Notificaciones no compatibles en este navegador.');
  } catch (e) { output(`No se pudo enviar la notificación: ${e.message}`); }
});
$('#fileBtn').addEventListener('click', async () => {
  try {
    const content = JSON.stringify({ name: $('#projectName').value || 'Mi aplicación', files: state.files, exportedAt: new Date().toISOString() }, null, 2);
    if (isNative) {
      const result = await Filesystem.writeFile({ path: 'creaapps-proyecto.json', data: content, directory: Directory.Documents, encoding: Encoding.UTF8, recursive: true });
      output(`Proyecto guardado en el almacenamiento de la app.\nRuta: ${result.uri}`);
    } else download('creaapps-proyecto.json', content, 'application/json');
  } catch (e) { output(`No se pudo guardar el archivo: ${e.message}`); }
});
